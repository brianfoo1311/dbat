SELECT human_category, time_period_name 
FROM time_period 
INNER JOIN  human_type ON human_type.time_period_ID=time_period.time_period_ID;

