SELECT time_period_name, date_mya 
FROM time_period 
INNER JOIN human_type on human_type.time_period_ID = time_period.time_period_ID 
ORDER BY date_mya ASC;
