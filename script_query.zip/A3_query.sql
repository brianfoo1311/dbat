SELECT area_name, COUNT(human_technologies_ID) as Number_Of_Technology, human_category 
FROM human_type
INNER JOIN human_tech on human_type.human_type_ID = human_tech.human_ID
INNER JOIN local_area on human_type.local_area_ID = local_area.local_area_ID
GROUP BY area_name, human_category
HAVING COUNT(human_tech.human_technologies_ID)>0;
