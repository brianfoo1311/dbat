SELECT small_area, Number_of_Small_Technology, period_name
FROM (SELECT small_area_name as small_area, count(small_technologies_ID) as Number_of_Small_Technology, time_period_name as period_name
FROM Small_local_area
INNER JOIN small_tech on small_tech.small_area_ID = small_local_area.small_local_area_ID
INNER JOIN technologies on small_tech.small_technologies_ID = technologies.technologies_ID
INNER JOIN time_period on technologies.time_period_ID = time_period.time_period_ID
GROUP BY small_area_name, time_period_name)
ORDER BY period_name ASC;
