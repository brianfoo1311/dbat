INSERT INTO Local_Area (Local_Area_ID, Area_Name) values ('L01','Kuala Lumpur')
INSERT INTO Local_Area (Local_Area_ID, Area_Name) values ('L02','Selangor')
INSERT INTO Local_Area (Local_Area_ID, Area_Name) values ('L03','Johor');
	




INSERT INTO Small_Local_Area (Small_Local_Area_ID,Small_Area_Name,Local_Area_ID) values ('SL01', 'Kuchai Lama', 'L01');

INSERT INTO Small_Local_Area (Small_Local_Area_ID,Small_Area_Name,Local_Area_ID) values ('SL02', 'Megah Medun', 'L01');

INSERT INTO Small_Local_Area (Small_Local_Area_ID,Small_Area_Name,Local_Area_ID) values ('SL03', 'Serdang', 'L02');
	
INSERT INTO Small_Local_Area (Small_Local_Area_ID,Small_Area_Name,Local_Area_ID) values ('SL04', 'Kota Damansara',  'L02');
INSERT INTO Small_Local_Area (Small_Local_Area_ID,Small_Area_Name,Local_Area_ID) values ('SL05', 'Sungai Buloh', 'L03');
INSERT INTO Small_Local_Area (Small_Local_Area_ID,Small_Area_Name,Local_Area_ID) values ('SL06', 'Puncak Alam', 'L03');


	


INSERT INTO Time_Period (Time_Period_ID, Time_Period_Name, Date_mya) values ('TP01', 'Stone Age',3.4);
INSERT INTO Time_Period (Time_Period_ID, Time_Period_Name, Date_mya) values ('TP02', 'Bronze Age',2.2);
INSERT INTO Time_Period (Time_Period_ID, Time_Period_Name, Date_mya) values ('TP03', 'Iron Age',1.1);
	



INSERT INTO Human_Type (Human_Type_ID, Human_Category, Local_Area_ID, Time_Period_ID) values ('H01','Australopithecus Afarensis', 'L01', 'TP01');
 
INSERT INTO Human_Type (Human_Type_ID, Human_Category, Local_Area_ID, Time_Period_ID) values ('H02','Australopithecus Africanus', 'L01', 'TP01'); 
INSERT INTO Human_Type (Human_Type_ID, Human_Category, Local_Area_ID, Time_Period_ID) values ('H03','Homo Habilis', 'L02', 'TP02'); 
INSERT INTO Human_Type (Human_Type_ID, Human_Category, Local_Area_ID, Time_Period_ID) values ('H04','Homo Erectus', 'L02', 'TP02');
INSERT INTO Human_Type (Human_Type_ID, Human_Category, Local_Area_ID, Time_Period_ID) values ('H05','Homo Neanderthalensis', 'L03', 'TP03');
INSERT INTO Human_Type (Human_Type_ID, Human_Category, Local_Area_ID, Time_Period_ID) values ('H06','Homo Sapiens', 'L03', 'TP03');
 	







INSERT INTO Technologies (Technologies_ID, Time_Period_ID, Technology_Name) values ('T01', 'TP01', 'Hammerstone');
INSERT INTO Technologies (Technologies_ID, Time_Period_ID, Technology_Name) values ('T02', 'TP01', 'Chopper');
INSERT INTO Technologies (Technologies_ID, Time_Period_ID, Technology_Name) values ('T03', 'TP01', 'Hand Axes');
INSERT INTO Technologies (Technologies_ID, Time_Period_ID, Technology_Name) values ('T04', 'TP01', 'Microlith');
INSERT INTO Technologies (Technologies_ID, Time_Period_ID, Technology_Name) values ('T05', 'TP01', 'Blade Cores');
INSERT INTO Technologies (Technologies_ID, Time_Period_ID, Technology_Name) values ('T06', 'TP01', 'Awls');
INSERT INTO Technologies (Technologies_ID, Time_Period_ID, Technology_Name) values ('T07', 'TP01', 'Burins');
INSERT INTO Technologies (Technologies_ID, Time_Period_ID, Technology_Name) values ('T08', 'TP01', 'Wooden Arrow');
INSERT INTO Technologies (Technologies_ID, Time_Period_ID, Technology_Name) values ('T09', 'TP01', 'Sharpened Sticks');
INSERT INTO Technologies (Technologies_ID, Time_Period_ID, Technology_Name) values ('T10', 'TP01', 'Nets');


INSERT INTO Technologies (Technologies_ID, Time_Period_ID, Technology_Name) values ('T11', 'TP02', 'Dagger Blade');
INSERT INTO Technologies (Technologies_ID, Time_Period_ID, Technology_Name) values ('T12', 'TP02', 'Spearheads');
INSERT INTO Technologies (Technologies_ID, Time_Period_ID, Technology_Name) values ('T13', 'TP02', 'Adzes');
INSERT INTO Technologies (Technologies_ID, Time_Period_ID, Technology_Name) values ('T14', 'TP02', 'Chisels');
INSERT INTO Technologies (Technologies_ID, Time_Period_ID, Technology_Name) values ('T15', 'TP02', 'Leather Shield');
INSERT INTO Technologies (Technologies_ID, Time_Period_ID, Technology_Name) values ('T16', 'TP02', 'Halberds');
INSERT INTO Technologies (Technologies_ID, Time_Period_ID, Technology_Name) values ('T17', 'TP02', 'Mallets');
INSERT INTO Technologies (Technologies_ID, Time_Period_ID, Technology_Name) values ('T18', 'TP02', 'Socketed Axe');
INSERT INTO Technologies (Technologies_ID, Time_Period_ID, Technology_Name) values ('T19', 'TP02', 'Bucket');
INSERT INTO Technologies (Technologies_ID, Time_Period_ID, Technology_Name) values ('T20', 'TP02', 'Dirk');


INSERT INTO Technologies (Technologies_ID, Time_Period_ID, Technology_Name) values ('T21', 'TP03', 'Rotary Quernstone');
INSERT INTO Technologies (Technologies_ID, Time_Period_ID, Technology_Name) values ('T22', 'TP03', 'Javelin');
INSERT INTO Technologies (Technologies_ID, Time_Period_ID, Technology_Name) values ('T23', 'TP03', 'Ard');
INSERT INTO Technologies (Technologies_ID, Time_Period_ID, Technology_Name) values ('T24', 'TP03', 'Coulter');
INSERT INTO Technologies (Technologies_ID, Time_Period_ID, Technology_Name) values ('T25', 'TP03', 'Iron Swords');
INSERT INTO Technologies (Technologies_ID, Time_Period_ID, Technology_Name) values ('T26', 'TP03', 'Lances');
INSERT INTO Technologies (Technologies_ID, Time_Period_ID, Technology_Name) values ('T27', 'TP03', 'Iron Sickle');


INSERT INTO Technologies (Technologies_ID, Time_Period_ID, Technology_Name) values ('T28', 'TP03', 'Anvil');
INSERT INTO Technologies (Technologies_ID, Time_Period_ID, Technology_Name) values ('T29', 'TP03', 'Knives');
INSERT INTO Technologies (Technologies_ID, Time_Period_ID, Technology_Name) values ('T30', 'TP03', 'Iron Rudder');




INSERT INTO Human_Tech (Human_Type_ID, Technologies_ID) values ('H01', 'T01');
INSERT INTO Human_Tech (Human_Type_ID, Technologies_ID) values ('H01', 'T02');
INSERT INTO Human_Tech (Human_Type_ID, Technologies_ID) values ('H01', 'T03');
INSERT INTO Human_Tech (Human_Type_ID, Technologies_ID) values ('H01', 'T04');
INSERT INTO Human_Tech (Human_Type_ID, Technologies_ID) values ('H01', 'T05');
INSERT INTO Human_Tech (Human_Type_ID, Technologies_ID) values ('H01', 'T06');
INSERT INTO Human_Tech (Human_Type_ID, Technologies_ID) values ('H01', 'T07');
INSERT INTO Human_Tech (Human_Type_ID, Technologies_ID) values ('H01', 'T08');
INSERT INTO Human_Tech (Human_Type_ID, Technologies_ID) values ('H01', 'T09');
INSERT INTO Human_Tech (Human_Type_ID, Technologies_ID) values ('H01', 'T10');

INSERT INTO Human_Tech (Human_Type_ID, Technologies_ID) values ('H02', 'T01');
INSERT INTO Human_Tech (Human_Type_ID, Technologies_ID) values ('H02', 'T02');
INSERT INTO Human_Tech (Human_Type_ID, Technologies_ID) values ('H02', 'T03');
INSERT INTO Human_Tech (Human_Type_ID, Technologies_ID) values ('H02', 'T04');
INSERT INTO Human_Tech (Human_Type_ID, Technologies_ID) values ('H02', 'T05');
INSERT INTO Human_Tech (Human_Type_ID, Technologies_ID) values ('H02', 'T06');
INSERT INTO Human_Tech (Human_Type_ID, Technologies_ID) values ('H02', 'T07');
INSERT INTO Human_Tech (Human_Type_ID, Technologies_ID) values ('H02', 'T08');
INSERT INTO Human_Tech (Human_Type_ID, Technologies_ID) values ('H02', 'T09');
INSERT INTO Human_Tech (Human_Type_ID, Technologies_ID) values ('H02', 'T10');


INSERT INTO Human_Tech (Human_Type_ID, Technologies_ID) values ('H03', 'T11');
INSERT INTO Human_Tech (Human_Type_ID, Technologies_ID) values ('H03', 'T12');
INSERT INTO Human_Tech (Human_Type_ID, Technologies_ID) values ('H03', 'T13');
INSERT INTO Human_Tech (Human_Type_ID, Technologies_ID) values ('H03', 'T14');
INSERT INTO Human_Tech (Human_Type_ID, Technologies_ID) values ('H03', 'T15');
INSERT INTO Human_Tech (Human_Type_ID, Technologies_ID) values ('H03', 'T16');
INSERT INTO Human_Tech (Human_Type_ID, Technologies_ID) values ('H03', 'T17');
INSERT INTO Human_Tech (Human_Type_ID, Technologies_ID) values ('H03', 'T18');
INSERT INTO Human_Tech (Human_Type_ID, Technologies_ID) values ('H03', 'T19');
INSERT INTO Human_Tech (Human_Type_ID, Technologies_ID) values ('H03', 'T20');


INSERT INTO Human_Tech (Human_Type_ID, Technologies_ID) values ('H04', 'T11');
INSERT INTO Human_Tech (Human_Type_ID, Technologies_ID) values ('H04', 'T12');
INSERT INTO Human_Tech (Human_Type_ID, Technologies_ID) values ('H04', 'T13');
INSERT INTO Human_Tech (Human_Type_ID, Technologies_ID) values ('H04', 'T14');
INSERT INTO Human_Tech (Human_Type_ID, Technologies_ID) values ('H04', 'T15');
INSERT INTO Human_Tech (Human_Type_ID, Technologies_ID) values ('H04', 'T16');
INSERT INTO Human_Tech (Human_Type_ID, Technologies_ID) values ('H04', 'T17');
INSERT INTO Human_Tech (Human_Type_ID, Technologies_ID) values ('H04', 'T18');
INSERT INTO Human_Tech (Human_Type_ID, Technologies_ID) values ('H04', 'T19');
INSERT INTO Human_Tech (Human_Type_ID, Technologies_ID) values ('H04', 'T20');


INSERT INTO Human_Tech (Human_Type_ID, Technologies_ID) values ('H05', 'T21');
INSERT INTO Human_Tech (Human_Type_ID, Technologies_ID) values ('H05', 'T22');
INSERT INTO Human_Tech (Human_Type_ID, Technologies_ID) values ('H05', 'T23');
INSERT INTO Human_Tech (Human_Type_ID, Technologies_ID) values ('H05', 'T24');
INSERT INTO Human_Tech (Human_Type_ID, Technologies_ID) values ('H05', 'T25');
INSERT INTO Human_Tech (Human_Type_ID, Technologies_ID) values ('H05', 'T26');
INSERT INTO Human_Tech (Human_Type_ID, Technologies_ID) values ('H05', 'T27');
INSERT INTO Human_Tech (Human_Type_ID, Technologies_ID) values ('H05', 'T28');
INSERT INTO Human_Tech (Human_Type_ID, Technologies_ID) values ('H05', 'T29');
INSERT INTO Human_Tech (Human_Type_ID, Technologies_ID) values ('H05', 'T30');


INSERT INTO Human_Tech (Human_Type_ID, Technologies_ID) values ('H06', 'T21');
INSERT INTO Human_Tech (Human_Type_ID, Technologies_ID) values ('H06', 'T22');
INSERT INTO Human_Tech (Human_Type_ID, Technologies_ID) values ('H06', 'T23');
INSERT INTO Human_Tech (Human_Type_ID, Technologies_ID) values ('H06', 'T24');
INSERT INTO Human_Tech (Human_Type_ID, Technologies_ID) values ('H06', 'T25');
INSERT INTO Human_Tech (Human_Type_ID, Technologies_ID) values ('H06', 'T26');
INSERT INTO Human_Tech (Human_Type_ID, Technologies_ID) values ('H06', 'T27');
INSERT INTO Human_Tech (Human_Type_ID, Technologies_ID) values ('H06', 'T28');
INSERT INTO Human_Tech (Human_Type_ID, Technologies_ID) values ('H06', 'T29');
INSERT INTO Human_Tech (Human_Type_ID, Technologies_ID) values ('H06', 'T30');


	


INSERT INTO Local_Tech (Local_Area_ID, Technologies_ID) values ('L01', 'T01');
INSERT INTO Local_Tech (Local_Area_ID, Technologies_ID) values ('L01', 'T02');
INSERT INTO Local_Tech (Local_Area_ID, Technologies_ID) values ('L01', 'T03');
INSERT INTO Local_Tech (Local_Area_ID, Technologies_ID) values ('L01', 'T04');
INSERT INTO Local_Tech (Local_Area_ID, Technologies_ID) values ('L01', 'T05');
INSERT INTO Local_Tech (Local_Area_ID, Technologies_ID) values ('L01', 'T06');
INSERT INTO Local_Tech (Local_Area_ID, Technologies_ID) values ('L01', 'T07');
INSERT INTO Local_Tech (Local_Area_ID, Technologies_ID) values ('L01', 'T08');
INSERT INTO Local_Tech (Local_Area_ID, Technologies_ID) values ('L01', 'T09');
INSERT INTO Local_Tech (Local_Area_ID, Technologies_ID) values ('L01', 'T10');



INSERT INTO Local_Tech (Local_Area_ID, Technologies_ID) values ('L02', 'T11');
INSERT INTO Local_Tech (Local_Area_ID, Technologies_ID) values ('L02', 'T12');
INSERT INTO Local_Tech (Local_Area_ID, Technologies_ID) values ('L02', 'T13');
INSERT INTO Local_Tech (Local_Area_ID, Technologies_ID) values ('L02', 'T14');
INSERT INTO Local_Tech (Local_Area_ID, Technologies_ID) values ('L02', 'T15');
INSERT INTO Local_Tech (Local_Area_ID, Technologies_ID) values ('L02', 'T16');
INSERT INTO Local_Tech (Local_Area_ID, Technologies_ID) values ('L02', 'T17');
INSERT INTO Local_Tech (Local_Area_ID, Technologies_ID) values ('L02', 'T18');
INSERT INTO Local_Tech (Local_Area_ID, Technologies_ID) values ('L02', 'T19');
INSERT INTO Local_Tech (Local_Area_ID, Technologies_ID) values ('L02', 'T20');

INSERT INTO Local_Tech (Local_Area_ID, Technologies_ID) values ('L03', 'T21');
INSERT INTO Local_Tech (Local_Area_ID, Technologies_ID) values ('L03', 'T22');
INSERT INTO Local_Tech (Local_Area_ID, Technologies_ID) values ('L03', 'T23');
INSERT INTO Local_Tech (Local_Area_ID, Technologies_ID) values ('L03', 'T24');
INSERT INTO Local_Tech (Local_Area_ID, Technologies_ID) values ('L03', 'T25');
INSERT INTO Local_Tech (Local_Area_ID, Technologies_ID) values ('L03', 'T26');
INSERT INTO Local_Tech (Local_Area_ID, Technologies_ID) values ('L03', 'T27');
INSERT INTO Local_Tech (Local_Area_ID, Technologies_ID) values ('L03', 'T28');
INSERT INTO Local_Tech (Local_Area_ID, Technologies_ID) values ('L03', 'T29');
INSERT INTO Local_Tech (Local_Area_ID, Technologies_ID) values ('L03', 'T30');

	




INSERT INTO Small_Tech (Small_Local_Area_ID, Technologies_ID) values ('SL01', 'T01');
INSERT INTO Small_Tech (Small_Local_Area_ID, Technologies_ID) values ('SL01', 'T02');
INSERT INTO Small_Tech (Small_Local_Area_ID, Technologies_ID) values ('SL01', 'T03');
INSERT INTO Small_Tech (Small_Local_Area_ID, Technologies_ID) values ('SL01', 'T04');
INSERT INTO Small_Tech (Small_Local_Area_ID, Technologies_ID) values ('SL01', 'T05');

INSERT INTO Small_Tech (Small_Local_Area_ID, Technologies_ID) values ('SL02', 'T06');
INSERT INTO Small_Tech (Small_Local_Area_ID, Technologies_ID) values ('SL02', 'T07');
INSERT INTO Small_Tech (Small_Local_Area_ID, Technologies_ID) values ('SL02', 'T08');
INSERT INTO Small_Tech (Small_Local_Area_ID, Technologies_ID) values ('SL02', 'T09');
INSERT INTO Small_Tech (Small_Local_Area_ID, Technologies_ID) values ('SL02', 'T10');

INSERT INTO Small_Tech (Small_Local_Area_ID, Technologies_ID) values ('SL03', 'T11');
INSERT INTO Small_Tech (Small_Local_Area_ID, Technologies_ID) values ('SL03', 'T12');
INSERT INTO Small_Tech (Small_Local_Area_ID, Technologies_ID) values ('SL03', 'T13');
INSERT INTO Small_Tech (Small_Local_Area_ID, Technologies_ID) values ('SL03', 'T14');
INSERT INTO Small_Tech (Small_Local_Area_ID, Technologies_ID) values ('SL03', 'T15');


INSERT INTO Small_Tech (Small_Local_Area_ID, Technologies_ID) values ('SL04', 'T16');
INSERT INTO Small_Tech (Small_Local_Area_ID, Technologies_ID) values ('SL04', 'T17');
INSERT INTO Small_Tech (Small_Local_Area_ID, Technologies_ID) values ('SL04', 'T18');
INSERT INTO Small_Tech (Small_Local_Area_ID, Technologies_ID) values ('SL04', 'T19');
INSERT INTO Small_Tech (Small_Local_Area_ID, Technologies_ID) values ('SL04', 'T20');

INSERT INTO Small_Tech (Small_Local_Area_ID, Technologies_ID) values ('SL05', 'T21');
INSERT INTO Small_Tech (Small_Local_Area_ID, Technologies_ID) values ('SL05', 'T22');
INSERT INTO Small_Tech (Small_Local_Area_ID, Technologies_ID) values ('SL05', 'T23');
INSERT INTO Small_Tech (Small_Local_Area_ID, Technologies_ID) values ('SL05', 'T24');
INSERT INTO Small_Tech (Small_Local_Area_ID, Technologies_ID) values ('SL05', 'T25');

INSERT INTO Small_Tech (Small_Local_Area_ID, Technologies_ID) values ('SL06', 'T26');
INSERT INTO Small_Tech (Small_Local_Area_ID, Technologies_ID) values ('SL06', 'T27');
INSERT INTO Small_Tech (Small_Local_Area_ID, Technologies_ID) values ('SL06', 'T28');
INSERT INTO Small_Tech (Small_Local_Area_ID, Technologies_ID) values ('SL06', 'T29');
INSERT INTO Small_Tech (Small_Local_Area_ID, Technologies_ID) values ('SL06', 'T30');

	



INSERT INTO Weapon (Weapon_ID, Weapon_Usage) values ('T04' , 'Used on arrow heads');
INSERT INTO Weapon (Weapon_ID, Weapon_Usage) values ('T08' , 'Used for hunting large animals'); 
INSERT INTO Weapon (Weapon_ID, Weapon_Usage) values ('T09' , 'Used for hunting animals');
INSERT INTO Weapon (Weapon_ID, Weapon_Usage) values ('T11' , 'Used for stabbing');
INSERT INTO Weapon (Weapon_ID, Weapon_Usage) values ('T12' , 'Used as far range weapon');
INSERT INTO Weapon (Weapon_ID, Weapon_Usage) values ('T15' , 'Used to protect from damage');
INSERT INTO Weapon (Weapon_ID, Weapon_Usage) values ('T16' , 'Used as sickle which is enable on the foot soldier');
INSERT INTO Weapon (Weapon_ID, Weapon_Usage) values ('T20' , 'Used as knife to stab people');
INSERT INTO Weapon (Weapon_ID, Weapon_Usage) values ('T22' , 'Used as hunting weapon');
INSERT INTO Weapon (Weapon_ID, Weapon_Usage) values ('T25' , 'Used during battles');
INSERT INTO Weapon (Weapon_ID, Weapon_Usage) values ('T26' , 'Used for hunting');
INSERT INTO Weapon (Weapon_ID, Weapon_Usage) values ('T29' , 'Used for hunting');





INSERT INTO Tool (Tool_ID, Tool_Usage) values ('T01', 'Used to chip other stones, nuts and bones');
INSERT INTO Tool (Tool_ID, Tool_Usage) values ('T02', 'For hacking,cutting, and chopping'); 
INSERT INTO Tool (Tool_ID, Tool_Usage) values ('T03', 'Used for butcher skin, cut wood and plants');
INSERT INTO Tool (Tool_ID, Tool_Usage) values ('T05', 'Used to break down stones');
INSERT INTO Tool (Tool_ID, Tool_Usage) values ('T06', 'Used for shredding plant fibers');
INSERT INTO Tool (Tool_ID, Tool_Usage) values ('T07', 'Used for carving bone or wood');
INSERT INTO Tool (Tool_ID, Tool_Usage) values ('T10', 'Used to catch fish');
INSERT INTO Tool (Tool_ID, Tool_Usage) values ('T13', 'Used for smoothing and carving wood');
INSERT INTO Tool (Tool_ID, Tool_Usage) values ('T14', 'Used to sharpened edge of blade');
INSERT INTO Tool (Tool_ID, Tool_Usage) values ('T17', 'Used to knock wooden pieces');
INSERT INTO Tool (Tool_ID, Tool_Usage) values ('T18', 'Used to chop down trees');
INSERT INTO Tool (Tool_ID, Tool_Usage) values ('T19', 'Used to carry water or wine');
INSERT INTO Tool (Tool_ID, Tool_Usage) values ('T21', 'Used to grind corn');
INSERT INTO Tool (Tool_ID, Tool_Usage) values ('T23', 'Used to plough fields');
INSERT INTO Tool (Tool_ID, Tool_Usage) values ('T24', 'Used to break up ground');
INSERT INTO Tool (Tool_ID, Tool_Usage) values ('T27', 'Used for cutting and reaping');
INSERT INTO Tool (Tool_ID, Tool_Usage) values ('T28', 'Used for hammering metal pieces');
INSERT INTO Tool (Tool_ID, Tool_Usage) values ('T30', 'Used on ship to make is steer its own');
